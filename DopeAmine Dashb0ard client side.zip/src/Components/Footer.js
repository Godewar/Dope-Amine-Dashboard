import React from "react";

const Footer = () => {
    return (
        <div className="footer">
            <p>CopyRight &copy; 2023. All Rights Reserved.</p>
        </div>
    )
}

export default Footer;